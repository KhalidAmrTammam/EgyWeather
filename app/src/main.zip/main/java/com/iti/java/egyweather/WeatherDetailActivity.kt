package com.iti.java.egyweather

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.WorkManager
import com.iti.java.egyweather.Model.LocalDataSource.WeatherDatabase
import com.iti.java.egyweather.Model.RemoteDataSource.RemoteDataSource
import com.iti.java.egyweather.Model.RemoteDataSource.RetrofitHelper
import com.iti.java.egyweather.Model.WeatherRepository
import java.util.Locale

class WeatherDetailActivity : ComponentActivity() {
    private val settingsViewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val lat = intent.getDoubleExtra("lat", 0.0)
        val lon = intent.getDoubleExtra("lon", 0.0)

        setContent {
            val viewModel: WeatherViewModel = viewModel(
                factory = WeatherViewModelFactory(
                    (application as MainApplication).repository,
                    WorkManager.getInstance(applicationContext),
                    settingsViewModel  // Add this
                )
            )

            ForecastScreen(lat = lat, lon = lon, viewModel = viewModel)
        }
    }
}

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        updateLanguage()
    }

    val repository: WeatherRepository by lazy {
        WeatherRepository(
            RemoteDataSource(RetrofitHelper.api),
            WeatherDatabase.getInstance(this).weatherDao(),
            this
        )
    }

    private fun updateLanguage() {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val useSystem = prefs.getBoolean("useSystemLanguage", true)
        val lang = if(useSystem) "system" else prefs.getString("language", "en") ?: "en"

        val locale = when {
            useSystem -> Locale.getDefault()
            lang == "ar" -> Locale("ar")
            else -> Locale("en")
        }

        Locale.setDefault(locale)
        val config = resources.configuration
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
    }
}